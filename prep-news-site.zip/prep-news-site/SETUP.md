# Panther Daily Digest — Setup Guide
### For someone who has never built a website. ~10 minutes, completely free.

This is a news website that **updates itself every morning** with the latest
Seattle Prep stories. You do not need to know any code. Just follow these steps.

---

## What you're publishing
- `index.html` — the website itself (this is what visitors see)
- `news.json` — the news data (this file gets refreshed automatically)
- `update_news.py` — the robot that fetches new stories each day
- `.github/workflows/update-news.yml` — tells the robot to run every morning

You will put these files on **GitHub**, a free service, and turn on free hosting
called **GitHub Pages**. GitHub will then run the updater for you automatically.

---

## Step 1 — Make a free GitHub account
1. Go to **https://github.com** and click **Sign up**.
2. Pick a username, e.g. `seaprep-news`. It's free.

## Step 2 — Create a place for the website
1. Click the **+** in the top-right → **New repository**.
2. Name it: **`panther-news`**
3. Choose **Public**.
4. Click **Create repository**.

## Step 3 — Upload these files
1. On your new repository page, click **uploading an existing file**.
2. Drag in **all** of these:
   - `index.html`
   - `news.json`
   - `update_news.py`
   - the **`.github`** folder (it contains the auto-updater)
   > Tip: if drag-and-drop won't take the folder, upload the loose files,
   > then upload the file inside `.github/workflows/update-news.yml` separately.
3. Click **Commit changes** at the bottom.

## Step 4 — Turn on the free website hosting
1. In your repository, click **Settings** (top menu).
2. On the left, click **Pages**.
3. Under **Branch**, choose **main**, folder **/ (root)**, click **Save**.
4. Wait about 1 minute. A green box will show your live web address, like:
   **`https://YOUR-USERNAME.github.io/panther-news/`**

🎉 That link is your live website. Share it with anyone.

## Step 5 — Turn on the daily auto-updates
1. In your repository, click the **Actions** tab.
2. If it asks, click **"I understand my workflows, enable them."**
3. That's it. Every morning at 6 AM Pacific the site refreshes itself.
   - Want to update it right now? Click **Actions → Update Prep News → Run workflow**.

---

## How do I add or change a news source later?
Open **`update_news.py`** on GitHub (click the file, then the pencil ✏️).
Near the top you'll see a `SOURCES` list. Add a line like the others with the
name and the RSS feed address of the new source, then **Commit changes**.

## Will it ever look broken?
No. If a source is ever down, the website automatically shows a set of
built-in verified stories instead of an empty page.

## Common questions
- **Is this really free?** Yes — GitHub Pages and Actions are free for public sites.
- **Do I need to keep my computer on?** No. GitHub runs everything in the cloud.
- **Can I use my own web address (like news.seaprep.org)?** Yes — in
  Settings → Pages there's a "Custom domain" box. Your IT person can point a
  domain there in a few minutes.

---

## Want your own web address (like news.seaprep.org)?
See **`CUSTOM-DOMAIN.md`** in this project for a step-by-step, no-code guide.
The `CNAME` file is already included — you'll just edit it to your address and
add one DNS record with your domain provider.
