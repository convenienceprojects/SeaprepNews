# Using Your Own Web Address (Custom Domain)
### Turn `https://yourname.github.io/panther-news/` into something like `news.seaprep.org`

This takes about 15 minutes, plus waiting time for the internet to catch up
(usually under an hour, sometimes up to a day). You'll need help from whoever
controls the school's domain name — usually the IT person or whoever set up the
school website. Show them this page.

---

## Part A — Pick your address
Decide the exact web address you want. A **subdomain** is easiest and recommended:
- `news.seaprep.org`  ← recommended
- `panther.seaprep.org`
- `digest.seaprep.org`

> A subdomain (`news.seaprep.org`) is far simpler and safer than using the bare
> domain (`seaprep.org`), because it won't interfere with the main school website.

The file named **`CNAME`** in this project already contains `news.seaprep.org`.
If you chose a different address, open that `CNAME` file on GitHub, click the
pencil ✏️, replace the text with your address, and Commit.

---

## Part B — Tell the school's domain to point at GitHub
This is the one step that needs the person who manages the school domain.
They will log in to wherever the domain is registered (GoDaddy, Cloudflare,
Namecheap, Google Domains, etc.) and add **one DNS record**:

| Setting       | Value                          |
|---------------|--------------------------------|
| Record type   | **CNAME**                      |
| Host / Name   | **news**  (just the subdomain part) |
| Points to     | **YOUR-USERNAME.github.io**    |
| TTL           | Automatic / default            |

> Replace `YOUR-USERNAME` with your actual GitHub username. Note there is **no**
> `/panther-news` on the end — it's just `YOUR-USERNAME.github.io`.

That's the whole DNS change. Save it.

---

## Part C — Tell GitHub about the address
1. In your repository, go to **Settings → Pages**.
2. Under **Custom domain**, type your address: `news.seaprep.org`
3. Click **Save**. GitHub will check the DNS (this is why Part B comes first).
4. Wait for the check to pass (the page shows a green checkmark). This can take
   a few minutes up to an hour while the internet updates.
5. Once it passes, tick the **Enforce HTTPS** box. This gives your site the
   secure padlock 🔒. (The box may be greyed out for a little while — that's
   normal; come back and tick it once it's available.)

Done. Visitors can now reach the site at **https://news.seaprep.org**.

---

## If you want the bare domain instead (seaprep.org with no "news.")
This is more involved and can affect the main school website, so only do it with
the domain manager. Instead of one CNAME record, they add **four A records** for
the host `@` pointing to GitHub's addresses:

```
185.199.108.153
185.199.109.153
185.199.110.153
185.199.111.153
```

Then set the **Custom domain** in Settings → Pages to your bare domain.

---

## Troubleshooting
- **"Domain's DNS record could not be verified."** The DNS change from Part B
  hasn't spread across the internet yet. Wait 30–60 minutes and click Save again.
- **The site shows up but says "not secure."** Wait for the green check, then
  tick **Enforce HTTPS**. The certificate takes a little while to issue.
- **The address stopped working after a daily auto-update.** The `CNAME` file
  must stay in the project. The auto-updater only touches `news.json`, so it
  leaves `CNAME` alone — but if you ever delete `CNAME`, the custom address turns
  off. Just re-add it.
- **I changed my mind about the address.** Edit the `CNAME` file AND the Custom
  domain box in Settings → Pages to match, and update the DNS record in Part B.
